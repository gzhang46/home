function d1=d1(x,y,t,sigma,b)

if t~=0
    d1=(log(x/y)+(b+sigma^2/2)*t)*((sigma*sqrt(t)))^(-1);
else
    d1=(b+sigma^2/2)/sigma*sqrt(t);
end