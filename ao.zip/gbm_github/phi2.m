function phi2=phi2(r,K,tao1,x,sigma,b,alpha)

phi2=K*exp(-r*tao1)*normcdf(-d2(x,K,tao1,sigma,b))-x*exp(-alpha*tao1)*normcdf(-d1(x,K,tao1,sigma,b));