K=10:1:70;r=4.88/100;sigma=0.2;T=0.5833;alpha=0;b=r;S0=40;
n=100;
delta=T/n;
%order 2
B1=zeros(n,length(K));
B1(n,:)=min(K,r*K/alpha);
option=optimoptions('fsolve','FunctionTolerance',1e-2,'StepTolerance',1e-2,'OptimalityTolerance',1e-6);
for k=1:1:length(K)
    for i=n-1:-1:1
        sumphii=@(z) sumphi(i,n,r,K(k),z,B1(:,k),sigma,b,alpha,delta);
        eqn=@(z) (K(k)-z-phi2app(r,log(K(k)),T-i*delta,log(z),sigma,b,alpha)-0.5*delta*(phiapp(r,log(K(k)),T-i*delta,log(z),log(B1(n,k)),sigma,b,alpha)+phiapp(r,log(K(k)),0.0000000001,log(z),log(z),sigma,b,alpha))-sumphii(z));
        B1(i,k)=fsolve(eqn,B1(i+1,k),option);
    end
end
P0=zeros(length(K),3);
for i=1:1:length(K)
    P0(i,1)=phi2app(r,log(K(i)),T,log(S0),sigma,b,alpha);
end
for i=1:1:length(K)
    for j=1:1:n
        P0(i,1)=P0(i,1)+phiapp(r,log(K(i)),j*delta,log(S0),log(B1(j,i)),sigma,b,alpha)*delta;
    end
end
 
%order 1
B2=zeros(n,length(K));
B2(n,:)=min(K,r*K/alpha);
option=optimoptions('fsolve','FunctionTolerance',1e-2,'StepTolerance',1e-2,'OptimalityTolerance',1e-6);
for k=1:1:length(K)
    for i=n-1:-1:1
        sumphii=@(z) sumphi(i,n,r,K(k),z,B2(:,k),sigma,b,alpha,delta);
        eqn=@(z) (K(k)-z-phi2app(r,log(K(k)),T-i*delta,log(z),sigma,b,alpha)-0.5*delta*(phiapp(r,log(K(k)),T-i*delta,log(z),log(B2(n,k)),sigma,b,alpha)+phiapp(r,log(K(k)),0.0000000001,log(z),log(z),sigma,b,alpha))-sumphii(z));
        B2(i,k)=fsolve(eqn,B2(i+1,k),option);
    end
end
for i=1:1:length(K)
    P0(i,2)=phi2app(r,log(K(i)),T,log(S0),sigma,b,alpha);
end
for i=1:1:length(K)
    for j=1:1:n
        P0(i,2)=P0(i,2)+phiapp(r,log(K(i)),j*delta,log(S0),log(B2(j,i)),sigma,b,alpha)*delta;
    end
end

%order 0
B3=zeros(n,length(K));
B3(n,:)=min(K,r*K/alpha);
option=optimoptions('fsolve','FunctionTolerance',1e-2,'StepTolerance',1e-2,'OptimalityTolerance',1e-6);
for k=1:1:length(K)
    for i=n-1:-1:1
        sumphii=@(z) sumphi(i,n,r,K(k),z,B3(:,k),sigma,b,alpha,delta);
        eqn=@(z) (K(k)-z-phi2app(r,log(K(k)),T-i*delta,log(z),sigma,b,alpha)-0.5*delta*(phiapp(r,log(K(k)),T-i*delta,log(z),log(B3(n,k)),sigma,b,alpha)+phiapp(r,log(K(k)),0.0000000001,log(z),log(z),sigma,b,alpha))-sumphii(z));
        B3(i,k)=fsolve(eqn,B3(i+1,k),option);
    end
end
for i=1:1:length(K)
    P0(i,3)=phi2app(r,log(K(i)),T,log(S0),sigma,b,alpha);
end
for i=1:1:length(K)
    for j=1:1:n
        P0(i,3)=P0(i,3)+phiapp(r,log(K(i)),j*delta,log(S0),log(B3(j,i)),sigma,b,alpha)*delta;
    end
end