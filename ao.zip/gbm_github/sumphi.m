function sumphi=sumphi(i,n,r,K,z,y,sigma,b,alpha,delta)
if i==n-1 
    sumphi=0;
else
    sumphi=0;
    for q=i+1:1:n-1
        sumphi=sumphi+phiapp(r,log(K),(q-i)*delta,log(z),log(y(q)),sigma,b,alpha)*delta;
    end
return 
end