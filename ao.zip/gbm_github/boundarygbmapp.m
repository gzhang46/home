K=[35,40,45];r=4.88/100;sigma=[0.2,0.3,0.4];b=r;alpha=r-b;S0=40;
T=[0.0833,0.3333,0.5833];N=length(K)*length(sigma)*length(T);
n=30;
delta=T/n;
B=zeros(n,N);
B(n,1:9)=min(K(1),r*K(1)/alpha);
B(n,10:18)=min(K(2),r*K(2)/alpha);
B(n,19:27)=min(K(3),r*K(3)/alpha);
option=optimoptions('fsolve','FunctionTolerance',1e-4,'StepTolerance',1e-4,'OptimalityTolerance',1e-4);
for j=1:1:3
    for k=1:1:3
        for m=1:1:3
            for i=n-1:-1:1
                sumphii=@(z) sumphi(i,n,r,K(j),z,B(:,9*(j-1)+3*(k-1)+m),sigma(k),b,alpha,delta(m));
                eqn=@(z) (K(j)-z-phi2app(r,log(K(j)),T(m)-i*delta(m),log(z),sigma(k),b,alpha)-0.5*delta(m)*(phiapp(r,log(K(j)),T(m)-i*delta(m),log(z),log(B(n,9*(j-1)+3*(k-1)+m)),sigma(k),b,alpha)+phiapp(r,log(K(j)),0,log(z),log(z),sigma(k),b,alpha))-sumphii(z));
                B(i,9*(j-1)+3*(k-1)+m)=fsolve(eqn,B(i+1,9*(j-1)+3*(k-1)+m),option);
            end
        end
    end
end
P0=zeros(N,1);
for j=1:1:3
    for k=1:1:3
        for m=1:1:3
            P0(9*(j-1)+3*(k-1)+m)=phi2app(r,log(K(j)),T(m),log(S0),sigma(k),b,alpha);
        end
    end
end

for j=1:1:3
    for k=1:1:3
        for m=1:1:3
            for i=1:1:n
               P0(9*(j-1)+3*(k-1)+m)=P0(9*(j-1)+3*(k-1)+m)+phiapp(r,log(K(j)),i*delta(m),log(S0),log(B(i,(9*(j-1)+3*(k-1)+m))),sigma(k),b,alpha)*delta(m);
            end
        end
    end
end
% save('gbm100.mat','B','P0');