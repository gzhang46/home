function d2=d2(x,y,t,sigma,b)

d2=d1(x,y,t,sigma,b)-sigma*sqrt(t);