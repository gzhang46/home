function normcdf2app=normcdf2app(x,y,t,sigma,b)
% if t~=0
    fun2=@(z) (1/(sqrt(2*pi*sigma.^2*t)))*exp(-(z-x).^2/(2*sigma.^2*t)+(z-x)*(b-sigma.^2/2)/(sigma.^2))*(1-(b-sigma.^2/2).^2/(2*sigma.^2)*t+(b-sigma.^2/2).^4/((2*sigma.^2)^2)*t^2/2);
% else 
%     t=0.00000000001;
%     fun=@(z) (1/(sqrt(2*pi*sigma.^2*t)))*exp(-(z-x).^2/(2*sigma.^2*t)+(z-x)*(b-sigma.^2/2)/(sigma.^2))*(1-(b-sigma.^2/2).^2/(2*sigma.^2)*t+(b-sigma.^2/2).^4/((2*sigma.^2)^2)*t^2/2);
% end   
 fun0=@(z) (1/(sqrt(2*pi*sigma.^2*t)))*exp(-(z-x).^2/(2*sigma.^2*t)+(z-x)*(b-sigma.^2/2)/(sigma.^2))*(1);
 fun1=@(z) (1/(sqrt(2*pi*sigma.^2*t)))*exp(-(z-x).^2/(2*sigma.^2*t)+(z-x)*(b-sigma.^2/2)/(sigma.^2))*(1-(b-sigma.^2/2).^2/(2*sigma.^2)*t);
normcdf2app=integral(fun0,0,y);