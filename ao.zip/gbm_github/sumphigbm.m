function sumphigbm=sumphigbm(i,n,r,K,z,y,sigma,b,alpha,delta)
if i==n-1 
    sumphigbm=0;
else
    sumphigbm=0;
    for q=i+1:1:n-1
        sumphigbm=sumphigbm+phi(r,K,(q-i)*delta,z,y(q),sigma,b,alpha)*delta;
    end
return 
end