function phi2app=phi2app(r,K,tao1,x,sigma,b,alpha)

phi2app=exp(K)*exp(-r*tao1)*normcdf2app(x,K,tao1,sigma,b)-exp(x)*exp(-alpha*tao1)*normcdf1app(x,K,tao1,sigma,b);