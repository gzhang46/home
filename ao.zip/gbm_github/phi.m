function phi=phi(r,K,tao2,x,y,sigma,b,alpha)
phi=r*K*exp(-r*tao2)*normcdf(-d2(x,y,tao2,sigma,b))-alpha*x*exp(-alpha*tao2)*normcdf(-d1(x,y,tao2,sigma,b));