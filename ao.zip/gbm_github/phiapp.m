function phiapp=phiapp(r,K,tao2,x,y,sigma,b,alpha)
phiapp=r*exp(K)*exp(-r*tao2)*normcdf2app(x,y,tao2,sigma,b)-alpha*exp(x)*exp(-alpha*tao2)*normcdf1app(x,y,tao2,sigma,b);